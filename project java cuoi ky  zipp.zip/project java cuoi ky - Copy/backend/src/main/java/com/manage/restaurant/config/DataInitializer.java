package com.manage.restaurant.config;

import com.manage.restaurant.model.Restaurant;
import com.manage.restaurant.model.User;
import com.manage.restaurant.service.MenuItemService;
import com.manage.restaurant.service.RestaurantService;
import com.manage.restaurant.service.RestaurantTableService;
import com.manage.restaurant.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private MenuItemService menuItemService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private RestaurantService restaurantService;
    
    @Autowired
    private RestaurantTableService restaurantTableService;

    @Override
    public void run(String... args) throws Exception {
        // Initialize default admin user if no users exist
        if (userService.getTotalUserCount() == 0) {
            User admin = new User();
            admin.setName("Admin User");
            admin.setEmail("admin@restaurant.com");
            admin.setPhoneNumber("+1234567890");
            admin.setPassword("admin123"); // This will be encoded by the service
            admin.setRole("ADMIN");
            userService.createUser(admin.getName(), 
                                 admin.getEmail(), admin.getPhoneNumber(), 
                                 admin.getPassword(), admin.getRole());
            System.out.println("Default admin user has been created.");
        }
        
        // Initialize default restaurant if no restaurants exist
        if (restaurantService.getTotalRestaurantCount() == 0) {
            Restaurant restaurant = restaurantService.createRestaurant(
                "The Grand Restaurant", 
                "123 Main Street, City, State 12345", 
                "+1987654321"
            );
            System.out.println("Default restaurant has been created.");
            
            // Initialize default tables for the restaurant
            if (restaurantTableService.getTableCountByRestaurant(restaurant.getId()) == 0) {
                // Create tables with different capacities
                for (int i = 1; i <= 10; i++) {
                    int capacity = (i <= 4) ? 2 : (i <= 8) ? 4 : 6;
                    restaurantTableService.createTable(restaurant.getId(), String.valueOf(i), capacity, "AVAILABLE");
                }
                System.out.println("Default restaurant tables have been created.");
            }
        }
        
        // Initialize default menu items if the database is empty
        if (menuItemService.getAllMenuItems().isEmpty()) {
            menuItemService.initializeDefaultMenuItems();
            System.out.println("Default menu items have been initialized.");
        }
    }
}