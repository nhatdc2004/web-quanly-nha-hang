package com.manage.restaurant.service;

import com.manage.restaurant.model.MenuItem;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public interface MenuItemService {

    // Basic CRUD operations
    List<MenuItem> getAllMenuItems();
    List<MenuItem> getAvailableMenuItems();
    Optional<MenuItem> getMenuItemById(Long id);
    MenuItem saveMenuItem(MenuItem menuItem);
    MenuItem updateMenuItem(Long id, MenuItem menuItem);
    void deleteMenuItem(Long id);

    // Category operations
    List<MenuItem> getMenuItemsByCategory(String category);
    List<String> getAllCategories();

    // Search operations
    List<MenuItem> searchMenuItemsByName(String name);
    List<MenuItem> getMenuItemsByPriceRange(BigDecimal minPrice, BigDecimal maxPrice);

    // Availability operations
    MenuItem toggleAvailability(Long id);
    void setAvailability(Long id, boolean available);

    // Bulk operations
    List<MenuItem> saveAllMenuItems(List<MenuItem> menuItems);
    List<MenuItem> saveMenuItemsBulk(List<MenuItem> menuItems);
    List<MenuItem> initializeDefaultMenuItems();
    
    // Delete all menu items except Phở Bò
    void deleteAllMenuItemsExceptPhoBo();
}