package com.manage.restaurant.service.impl;

import com.manage.restaurant.model.Restaurant;
import com.manage.restaurant.repository.RestaurantRepository;
import com.manage.restaurant.service.RestaurantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class RestaurantServiceImpl implements RestaurantService {

    @Autowired
    private RestaurantRepository restaurantRepository;

    @Override
    public List<Restaurant> getAllRestaurants() {
        return restaurantRepository.findAll();
    }

    @Override
    public Optional<Restaurant> getRestaurantById(Long id) {
        return restaurantRepository.findById(id);
    }

    @Override
    public Restaurant saveRestaurant(Restaurant restaurant) {
        return restaurantRepository.save(restaurant);
    }

    @Override
    public Restaurant updateRestaurant(Long id, Restaurant restaurant) {
        if (restaurantRepository.existsById(id)) {
            restaurant.setId(id);
            return restaurantRepository.save(restaurant);
        }
        throw new RuntimeException("Restaurant not found with id: " + id);
    }

    @Override
    public void deleteRestaurant(Long id) {
        restaurantRepository.deleteById(id);
    }

    @Override
    public Optional<Restaurant> getRestaurantByName(String name) {
        return restaurantRepository.findByName(name);
    }

    @Override
    public List<Restaurant> getRestaurantsByAddress(String address) {
        return restaurantRepository.findByAddressContainingIgnoreCase(address);
    }

    @Override
    public Optional<Restaurant> getRestaurantByPhoneNumber(String phoneNumber) {
        return restaurantRepository.findByPhoneNumber(phoneNumber);
    }

    @Override
    public boolean existsByName(String name) {
        return restaurantRepository.existsByName(name);
    }

    @Override
    public boolean existsByPhoneNumber(String phoneNumber) {
        return restaurantRepository.existsByPhoneNumber(phoneNumber);
    }

    @Override
    public Restaurant createRestaurant(String name, String address, String phoneNumber) {
        if (existsByName(name)) {
            throw new RuntimeException("Restaurant with name already exists: " + name);
        }
        if (existsByPhoneNumber(phoneNumber)) {
            throw new RuntimeException("Restaurant with phone number already exists: " + phoneNumber);
        }
        
        Restaurant restaurant = new Restaurant();
        restaurant.setName(name);
        restaurant.setAddress(address);
        restaurant.setPhoneNumber(phoneNumber);
        
        return restaurantRepository.save(restaurant);
    }

    @Override
    public Restaurant updateRestaurantInfo(Long id, String name, String address, String phoneNumber) {
        Optional<Restaurant> restaurantOpt = restaurantRepository.findById(id);
        if (restaurantOpt.isPresent()) {
            Restaurant restaurant = restaurantOpt.get();
            
            // Check if name is being changed and if new name already exists
            if (!restaurant.getName().equals(name) && existsByName(name)) {
                throw new RuntimeException("Restaurant name already exists: " + name);
            }
            
            // Check if phone number is being changed and if new phone number already exists
            if (!restaurant.getPhoneNumber().equals(phoneNumber) && existsByPhoneNumber(phoneNumber)) {
                throw new RuntimeException("Phone number already exists: " + phoneNumber);
            }
            
            restaurant.setName(name);
            restaurant.setAddress(address);
            restaurant.setPhoneNumber(phoneNumber);
            
            return restaurantRepository.save(restaurant);
        }
        throw new RuntimeException("Restaurant not found with id: " + id);
    }

    @Override
    public List<Restaurant> searchRestaurantsByName(String name) {
        return restaurantRepository.findByNameContainingIgnoreCase(name);
    }

    @Override
    public List<Restaurant> searchRestaurantsByAddress(String address) {
        return restaurantRepository.findByAddressContainingIgnoreCase(address);
    }

    @Override
    public List<Restaurant> searchRestaurants(String keyword) {
        return restaurantRepository.findByNameContainingIgnoreCaseOrAddressContainingIgnoreCase(keyword, keyword);
    }

    @Override
    public long getTotalRestaurantCount() {
        return restaurantRepository.count();
    }
}