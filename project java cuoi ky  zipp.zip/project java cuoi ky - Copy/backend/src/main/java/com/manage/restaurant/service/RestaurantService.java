package com.manage.restaurant.service;

import com.manage.restaurant.model.Restaurant;

import java.util.List;
import java.util.Optional;

public interface RestaurantService {

    // Basic CRUD operations
    List<Restaurant> getAllRestaurants();
    Optional<Restaurant> getRestaurantById(Long id);
    Restaurant saveRestaurant(Restaurant restaurant);
    Restaurant updateRestaurant(Long id, Restaurant restaurant);
    void deleteRestaurant(Long id);

    // Find operations
    Optional<Restaurant> getRestaurantByName(String name);
    List<Restaurant> getRestaurantsByAddress(String address);
    Optional<Restaurant> getRestaurantByPhoneNumber(String phoneNumber);

    // Existence checks
    boolean existsByName(String name);
    boolean existsByPhoneNumber(String phoneNumber);

    // Restaurant creation and management
    Restaurant createRestaurant(String name, String address, String phoneNumber);
    Restaurant updateRestaurantInfo(Long id, String name, String address, String phoneNumber);

    // Search operations
    List<Restaurant> searchRestaurantsByName(String name);
    List<Restaurant> searchRestaurantsByAddress(String address);
    List<Restaurant> searchRestaurants(String keyword);

    // Statistics
    long getTotalRestaurantCount();
}