package com.manage.restaurant.service.impl;

import com.manage.restaurant.model.Booking;
import com.manage.restaurant.model.User;
import com.manage.restaurant.model.Restaurant;
import com.manage.restaurant.model.RestaurantTable;
import com.manage.restaurant.repository.BookingRepository;
import com.manage.restaurant.repository.UserRepository;
import com.manage.restaurant.repository.RestaurantRepository;
import com.manage.restaurant.repository.RestaurantTableRepository;
import com.manage.restaurant.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class BookingServiceImpl implements BookingService {

    @Autowired
    private BookingRepository bookingRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private RestaurantRepository restaurantRepository;
    
    @Autowired
    private RestaurantTableRepository restaurantTableRepository;

    @Override
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    @Override
    public Optional<Booking> getBookingById(Long id) {
        return bookingRepository.findById(id);
    }

    @Override
    public Booking saveBooking(Booking booking) {
        return bookingRepository.save(booking);
    }

    @Override
    public Booking updateBooking(Long id, Booking booking) {
        if (bookingRepository.existsById(id)) {
            booking.setId(id);
            return bookingRepository.save(booking);
        }
        throw new RuntimeException("Booking not found with id: " + id);
    }

    @Override
    public void deleteBooking(Long id) {
        bookingRepository.deleteById(id);
    }

    @Override
    public Booking createBooking(Long userId, Long restaurantId, Long tableId, 
                                LocalDateTime bookingTime, int numberOfGuests, String notes) {
        Optional<User> userOpt = userRepository.findById(userId);
        Optional<Restaurant> restaurantOpt = restaurantRepository.findById(restaurantId);
        Optional<RestaurantTable> tableOpt = restaurantTableRepository.findById(tableId);
        
        if (!userOpt.isPresent()) {
            throw new RuntimeException("User not found with id: " + userId);
        }
        if (!restaurantOpt.isPresent()) {
            throw new RuntimeException("Restaurant not found with id: " + restaurantId);
        }
        if (!tableOpt.isPresent()) {
            throw new RuntimeException("Table not found with id: " + tableId);
        }
        
        if (!isTableAvailable(tableId, bookingTime)) {
            throw new RuntimeException("Table is not available at the requested time");
        }
        
        Booking booking = new Booking();
        booking.setUser(userOpt.get());
        booking.setRestaurant(restaurantOpt.get());
        booking.setTable(tableOpt.get());
        booking.setBookingTime(bookingTime);
        booking.setNumberOfGuests(numberOfGuests);
        booking.setNotes(notes);
        booking.setStatus("PENDING");
        
        return bookingRepository.save(booking);
    }

    @Override
    public Booking createBookingWithUserInfo(String userName, String userEmail, String userPhone,
                                            Long restaurantId, Long tableId, LocalDateTime bookingTime, 
                                            int numberOfGuests, String notes) {
        // Try to find existing user by email
        Optional<User> userOpt = userRepository.findByEmail(userEmail);
        User user;
        
        if (userOpt.isPresent()) {
            user = userOpt.get();
        } else {
            // Create new user
            user = new User();
            user.setName(userName);
            user.setEmail(userEmail);
            user.setPhoneNumber(userPhone);
            user.setPassword("temp123"); // Temporary password
            user.setRole("CUSTOMER");
            user = userRepository.save(user);
        }
        
        return createBooking(user.getId(), restaurantId, tableId, bookingTime, numberOfGuests, notes);
    }

    @Override
    public boolean isTableAvailable(Long tableId, LocalDateTime bookingTime) {
        // Check if there's any booking for this table at the same time (within 2 hours)
        LocalDateTime startTime = bookingTime.minusHours(2);
        LocalDateTime endTime = bookingTime.plusHours(2);
        
        List<Booking> conflictingBookings = bookingRepository.findByTableAndBookingTimeBetween(
            restaurantTableRepository.findById(tableId).orElse(null), startTime, endTime);
        
        return conflictingBookings.isEmpty();
    }

    @Override
    public boolean isRestaurantAvailable(Long restaurantId, LocalDateTime bookingTime, int numberOfGuests) {
        List<RestaurantTable> availableTables = getAvailableTables(restaurantId, bookingTime);
        return availableTables.stream().anyMatch(table -> table.getCapacity() >= numberOfGuests);
    }

    @Override
    public List<RestaurantTable> getAvailableTables(Long restaurantId, LocalDateTime bookingTime) {
        List<RestaurantTable> allTables = restaurantTableRepository.findByRestaurantId(restaurantId);
        return allTables.stream()
            .filter(table -> isTableAvailable(table.getId(), bookingTime))
            .collect(Collectors.toList());
    }

    @Override
    public List<LocalDateTime> getAvailableTimeSlots(Long restaurantId, LocalDateTime startTime, LocalDateTime endTime) {
        // This is a simplified implementation - in practice, you'd want more sophisticated logic
        List<LocalDateTime> timeSlots = List.of(
            startTime.withHour(12).withMinute(0),
            startTime.withHour(13).withMinute(0),
            startTime.withHour(14).withMinute(0),
            startTime.withHour(18).withMinute(0),
            startTime.withHour(19).withMinute(0),
            startTime.withHour(20).withMinute(0)
        );
        
        return timeSlots.stream()
            .filter(time -> time.isAfter(startTime) && time.isBefore(endTime))
            .filter(time -> isRestaurantAvailable(restaurantId, time, 1))
            .collect(Collectors.toList());
    }

    @Override
    public Booking updateBookingStatus(Long id, String status) {
        Optional<Booking> bookingOpt = bookingRepository.findById(id);
        if (bookingOpt.isPresent()) {
            Booking booking = bookingOpt.get();
            booking.setStatus(status);
            return bookingRepository.save(booking);
        }
        throw new RuntimeException("Booking not found with id: " + id);
    }

    @Override
    public List<Booking> getBookingsByStatus(String status) {
        return bookingRepository.findByStatus(status);
    }

    @Override
    public List<Booking> getBookingsByUser(User user) {
        return bookingRepository.findByUser(user);
    }

    @Override
    public List<Booking> getBookingsByUserId(Long userId) {
        return bookingRepository.findByUserId(userId);
    }

    @Override
    public List<Booking> getBookingsByUserEmail(String email) {
        return bookingRepository.findByUserEmail(email);
    }

    @Override
    public List<Booking> getUpcomingBookingsByUser(Long userId) {
        return bookingRepository.findUpcomingBookingsByUser(userId, LocalDateTime.now());
    }

    @Override
    public List<Booking> getPastBookingsByUser(Long userId) {
        return bookingRepository.findByUserIdAndBookingTimeBefore(userId, LocalDateTime.now());
    }

    @Override
    public List<Booking> getBookingsByRestaurant(Restaurant restaurant) {
        return bookingRepository.findByRestaurant(restaurant);
    }

    @Override
    public List<Booking> getBookingsByRestaurantId(Long restaurantId) {
        return bookingRepository.findByRestaurantId(restaurantId);
    }

    @Override
    public List<Booking> getBookingsByRestaurantAndStatus(Long restaurantId, String status) {
        return bookingRepository.findByRestaurantId(restaurantId).stream()
            .filter(booking -> status.equals(booking.getStatus()))
            .collect(Collectors.toList());
    }

    @Override
    public List<Booking> getBookingsByTable(RestaurantTable table) {
        return bookingRepository.findByTable(table);
    }

    @Override
    public List<Booking> getBookingsByTableId(Long tableId) {
        return bookingRepository.findByTableId(tableId);
    }

    @Override
    public List<Booking> getBookingsByTableAndTimeRange(Long tableId, LocalDateTime startTime, LocalDateTime endTime) {
        return bookingRepository.findByTableAndTimeRange(tableId, startTime, endTime);
    }

    @Override
    public List<Booking> getBookingsByTimeRange(LocalDateTime startTime, LocalDateTime endTime) {
        return bookingRepository.findByBookingTimeBetween(startTime, endTime);
    }

    @Override
    public List<Booking> getBookingsForDate(LocalDateTime date) {
        LocalDateTime startOfDay = date.toLocalDate().atStartOfDay();
        LocalDateTime endOfDay = startOfDay.plusDays(1).minusSeconds(1);
        return getBookingsByTimeRange(startOfDay, endOfDay);
    }

    @Override
    public List<Booking> getTodaysBookings() {
        return getBookingsForDate(LocalDateTime.now());
    }

    @Override
    public List<Booking> getUpcomingBookings() {
        return bookingRepository.findByBookingTimeAfter(LocalDateTime.now());
    }

    @Override
    public Booking confirmBooking(Long id) {
        return updateBookingStatus(id, "CONFIRMED");
    }

    @Override
    public Booking cancelBooking(Long id) {
        return updateBookingStatus(id, "CANCELLED");
    }

    @Override
    public Booking completeBooking(Long id) {
        return updateBookingStatus(id, "COMPLETED");
    }

    @Override
    public Booking markAsNoShow(Long id) {
        return updateBookingStatus(id, "NO_SHOW");
    }

    @Override
    public long getBookingCount() {
        return bookingRepository.count();
    }

    @Override
    public long getBookingCountByStatus(String status) {
        return bookingRepository.countByStatus(status);
    }

    @Override
    public long getBookingCountByRestaurant(Long restaurantId) {
        return bookingRepository.countByRestaurantId(restaurantId);
    }

    @Override
    public long getBookingCountByUser(Long userId) {
        return bookingRepository.countByUserId(userId);
    }

    @Override
    public int getTotalGuestsAtTime(Long restaurantId, LocalDateTime bookingTime) {
        Integer result = bookingRepository.getTotalGuestsAtTimeForRestaurant(restaurantId, bookingTime);
        return result != null ? result : 0;
    }

    @Override
    public int getTotalGuestsForTable(Long tableId, LocalDateTime bookingTime) {
        // Since there's no direct method for table guests, we'll query by table and time
        List<Booking> bookings = bookingRepository.findByTableAndBookingTimeBetween(
            restaurantTableRepository.findById(tableId).orElse(null), 
            bookingTime.minusMinutes(30), 
            bookingTime.plusMinutes(30)
        );
        return bookings.stream()
            .filter(b -> "PENDING".equals(b.getStatus()) || "CONFIRMED".equals(b.getStatus()))
            .mapToInt(Booking::getNumberOfGuests)
            .sum();
    }

    @Override
    public List<Booking> searchBookingsByUserName(String userName) {
        return bookingRepository.findByUserNameContainingIgnoreCase(userName);
    }

    @Override
    public List<Booking> searchBookingsByUserEmail(String userEmail) {
        return bookingRepository.findByUserEmail(userEmail);
    }

    @Override
    public List<Booking> searchBookingsByNotes(String keyword) {
        return bookingRepository.findByNotesContainingIgnoreCase(keyword);
    }
}