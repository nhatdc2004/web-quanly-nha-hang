package com.manage.restaurant.service;

import com.manage.restaurant.model.User;

import java.util.List;
import java.util.Optional;

public interface UserService {

    // Basic CRUD operations
    List<User> getAllUsers();
    Optional<User> getUserById(Long id);
    User saveUser(User user);
    User updateUser(Long id, User user);
    void deleteUser(Long id);

    // Find operations
    Optional<User> getUserByEmail(String email);
    Optional<User> getUserByPhoneNumber(String phoneNumber);
    List<User> getUsersByRole(String role);

    // Existence checks
    boolean existsByEmail(String email);
    boolean existsByPhoneNumber(String phoneNumber);

    // User creation and management
    User createUser(String name, String email, String phoneNumber, String password, String role);
    User createOrGetUser(String name, String email, String phoneNumber);
    User updateUserInfo(Long id, String name, String email, String phoneNumber);
    User updateUserPassword(Long id, String newPassword);
    User updateUserRole(Long id, String role);

    // Authentication
    Optional<User> authenticateUser(String email, String password);
    boolean validatePassword(String email, String password);

    // Search operations
    List<User> searchUsersByName(String name);
    List<User> searchUsersByEmail(String email);
    
    // Role-based operations
    List<User> getCustomers();
    List<User> getAdmins();
    List<User> getStaff();
    
    // User statistics
    long getTotalUserCount();
    long getUserCountByRole(String role);
}