package com.manage.restaurant.service;

import com.manage.restaurant.model.RestaurantTable;
import com.manage.restaurant.model.Restaurant;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface RestaurantTableService {

    // Basic CRUD operations
    List<RestaurantTable> getAllTables();
    Optional<RestaurantTable> getTableById(Long id);
    RestaurantTable saveTable(RestaurantTable table);
    RestaurantTable updateTable(Long id, RestaurantTable table);
    void deleteTable(Long id);

    // Restaurant-based operations
    List<RestaurantTable> getTablesByRestaurant(Restaurant restaurant);
    List<RestaurantTable> getTablesByRestaurantId(Long restaurantId);
    Optional<RestaurantTable> getTableByRestaurantAndTableNumber(Long restaurantId, int tableNumber);

    // Status-based operations
    List<RestaurantTable> getTablesByStatus(String status);
    List<RestaurantTable> getTablesByRestaurantAndStatus(Long restaurantId, String status);
    RestaurantTable updateTableStatus(Long id, String status);

    // Capacity-based operations
    List<RestaurantTable> getTablesByCapacity(int capacity);
    List<RestaurantTable> getTablesByMinimumCapacity(int minCapacity);
    List<RestaurantTable> getTablesByRestaurantAndCapacity(Long restaurantId, int capacity);
    List<RestaurantTable> getTablesByRestaurantAndMinimumCapacity(Long restaurantId, int minCapacity);

    // Availability operations
    List<RestaurantTable> getAvailableTablesByRestaurant(Long restaurantId);
    List<RestaurantTable> getAvailableTablesByRestaurantAndCapacity(Long restaurantId, int minCapacity);
    boolean isTableAvailable(Long tableId, LocalDateTime bookingTime);

    // Table creation and management
    RestaurantTable createTable(Long restaurantId, String tableNumber, int capacity, String status);
    RestaurantTable updateTableInfo(Long id, String tableNumber, int capacity, String status);

    // Statistics
    long getTableCountByRestaurant(Long restaurantId);
    int getTotalCapacityByRestaurant(Long restaurantId);
    long getAvailableTableCount(Long restaurantId);
    long getTableCountByStatus(String status);

    // Search operations
    List<RestaurantTable> searchTablesByRestaurantName(String restaurantName);
    Optional<RestaurantTable> findTableByRestaurantAndNumber(Long restaurantId, int tableNumber);

    // Existence checks
    boolean existsByRestaurantAndTableNumber(Long restaurantId, String tableNumber);
    
    // Time-based availability operations
    List<RestaurantTable> getAvailableTablesByTimeRange(Long restaurantId, LocalDateTime startTime, LocalDateTime endTime);
    
    // Reservation operations
    RestaurantTable reserveTable(Long tableId, LocalDateTime reservationTime, int duration);
    RestaurantTable cancelReservation(Long tableId);
    
    // Advanced statistics and analytics
    java.util.Map<String, Object> getTableStatistics(Long restaurantId);
    
    // Advanced search operations
    Optional<RestaurantTable> findNearestAvailableTable(Long restaurantId, int requiredCapacity, LocalDateTime preferredTime);
    
    // Bulk operations
    List<RestaurantTable> bulkUpdateTables(List<java.util.Map<String, Object>> tablesData);
    
    // Usage history
    List<java.util.Map<String, Object>> getTableUsageHistory(Long tableId, LocalDateTime fromDate, LocalDateTime toDate);
    boolean existsByRestaurantAndTableNumber(Long restaurantId, int tableNumber);
}