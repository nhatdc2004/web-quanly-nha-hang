package com.manage.restaurant.controller;

import com.manage.restaurant.model.ContactMessage;
import com.manage.restaurant.service.ContactMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/contact")
@CrossOrigin(origins = "*")
public class ContactMessageController {

    @Autowired
    private ContactMessageService contactMessageService;

    @GetMapping("/messages")
    public ResponseEntity<List<ContactMessage>> getAllMessages() {
        List<ContactMessage> messages = contactMessageService.getAllContactMessages();
        return ResponseEntity.ok(messages);
    }

    @GetMapping("/messages/{id}")
    public ResponseEntity<ContactMessage> getMessageById(@PathVariable Long id) {
        Optional<ContactMessage> message = contactMessageService.getContactMessageById(id);
        return message.map(ResponseEntity::ok)
                     .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/messages")
    public ResponseEntity<ContactMessage> createMessage(@RequestBody Map<String, String> messageData) {
        try {
            String name = messageData.get("name");
            String email = messageData.get("email");
            String phone = messageData.get("phone");
            String subject = messageData.get("subject");
            String messageText = messageData.get("message");
            
            ContactMessage savedMessage = contactMessageService.createContactMessage(name, email, phone, subject, messageText);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedMessage);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @PutMapping("/messages/{id}")
    public ResponseEntity<ContactMessage> updateMessage(@PathVariable Long id, @RequestBody ContactMessage message) {
        try {
            ContactMessage updatedMessage = contactMessageService.updateContactMessage(id, message);
            return ResponseEntity.ok(updatedMessage);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @DeleteMapping("/messages/{id}")
    public ResponseEntity<Void> deleteMessage(@PathVariable Long id) {
        try {
            contactMessageService.deleteContactMessage(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/messages/{id}/status")
    public ResponseEntity<ContactMessage> updateMessageStatus(
            @PathVariable Long id, 
            @RequestBody Map<String, String> statusData) {
        try {
            ContactMessage.MessageStatus status = ContactMessage.MessageStatus.valueOf(statusData.get("status"));
            ContactMessage updatedMessage = contactMessageService.updateMessageStatus(id, status);
            return ResponseEntity.ok(updatedMessage);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @GetMapping("/messages/status/{status}")
    public ResponseEntity<List<ContactMessage>> getMessagesByStatus(@PathVariable String status) {
        try {
            ContactMessage.MessageStatus messageStatus = ContactMessage.MessageStatus.valueOf(status.toUpperCase());
            List<ContactMessage> messages = contactMessageService.getMessagesByStatus(messageStatus);
            return ResponseEntity.ok(messages);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/messages/email/{email}")
    public ResponseEntity<List<ContactMessage>> getMessagesByEmail(@PathVariable String email) {
        List<ContactMessage> messages = contactMessageService.getMessagesByEmail(email);
        return ResponseEntity.ok(messages);
    }

    @GetMapping("/messages/date-range")
    public ResponseEntity<List<ContactMessage>> getMessagesByDateRange(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate) {
        List<ContactMessage> messages = contactMessageService.getMessagesByDateRange(startDate, endDate);
        return ResponseEntity.ok(messages);
    }

    @GetMapping("/messages/search")
    public ResponseEntity<List<ContactMessage>> searchMessages(@RequestParam String keyword) {
        List<ContactMessage> messages = contactMessageService.searchMessagesByKeyword(keyword);
        return ResponseEntity.ok(messages);
    }

    @GetMapping("/messages/new")
    public ResponseEntity<List<ContactMessage>> getNewMessages() {
        List<ContactMessage> messages = contactMessageService.getNewMessages();
        return ResponseEntity.ok(messages);
    }

    @GetMapping("/messages/in-progress")
    public ResponseEntity<List<ContactMessage>> getInProgressMessages() {
        List<ContactMessage> messages = contactMessageService.getInProgressMessages();
        return ResponseEntity.ok(messages);
    }

    @GetMapping("/messages/resolved")
    public ResponseEntity<List<ContactMessage>> getResolvedMessages() {
        List<ContactMessage> messages = contactMessageService.getResolvedMessages();
        return ResponseEntity.ok(messages);
    }

    @PostMapping("/messages/{id}/in-progress")
    public ResponseEntity<ContactMessage> markAsInProgress(@PathVariable Long id) {
        try {
            ContactMessage updatedMessage = contactMessageService.markAsInProgress(id);
            return ResponseEntity.ok(updatedMessage);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/messages/{id}/resolved")
    public ResponseEntity<ContactMessage> markAsResolved(@PathVariable Long id) {
        try {
            ContactMessage updatedMessage = contactMessageService.markAsResolved(id);
            return ResponseEntity.ok(updatedMessage);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/statistics")
    public ResponseEntity<Map<String, Long>> getMessageStatistics() {
        Map<String, Long> statistics = Map.of(
            "total", contactMessageService.getTotalMessageCount(),
            "new", contactMessageService.getNewMessageCount(),
            "inProgress", contactMessageService.getInProgressMessageCount(),
            "resolved", contactMessageService.getResolvedMessageCount()
        );
        return ResponseEntity.ok(statistics);
    }

    @GetMapping("/statistics/status/{status}")
    public ResponseEntity<Long> getMessageCountByStatus(@PathVariable String status) {
        try {
            ContactMessage.MessageStatus messageStatus = ContactMessage.MessageStatus.valueOf(status.toUpperCase());
            long count = contactMessageService.getMessageCountByStatus(messageStatus);
            return ResponseEntity.ok(count);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }
    }
}