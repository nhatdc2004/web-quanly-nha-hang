package com.manage.restaurant.controller;

import com.manage.restaurant.model.Booking;
import com.manage.restaurant.model.RestaurantTable;
import com.manage.restaurant.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin(origins = "*")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @GetMapping
    public ResponseEntity<List<Booking>> getAllBookings() {
        List<Booking> bookings = bookingService.getAllBookings();
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Booking> getBookingById(@PathVariable Long id) {
        Optional<Booking> booking = bookingService.getBookingById(id);
        return booking.map(ResponseEntity::ok)
                     .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Booking> createBooking(@RequestBody Map<String, Object> bookingData) {
        try {
            Long userId = Long.valueOf(bookingData.get("userId").toString());
            Long restaurantId = Long.valueOf(bookingData.get("restaurantId").toString());
            Long tableId = Long.valueOf(bookingData.get("tableId").toString());
            LocalDateTime bookingTime = LocalDateTime.parse((String) bookingData.get("bookingTime"));
            int numberOfGuests = (Integer) bookingData.get("numberOfGuests");
            String notes = (String) bookingData.get("notes");
            
            Booking booking = bookingService.createBooking(userId, restaurantId, tableId, 
                                                          bookingTime, numberOfGuests, notes);
            return ResponseEntity.status(HttpStatus.CREATED).body(booking);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }

    @PostMapping("/with-user-info")
    public ResponseEntity<Booking> createBookingWithUserInfo(@RequestBody Map<String, Object> bookingData) {
        try {
            String userName = (String) bookingData.get("userName");
            String userEmail = (String) bookingData.get("userEmail");
            String userPhone = (String) bookingData.get("userPhone");
            Long restaurantId = Long.valueOf(bookingData.get("restaurantId").toString());
            Long tableId = Long.valueOf(bookingData.get("tableId").toString());
            LocalDateTime bookingTime = LocalDateTime.parse((String) bookingData.get("bookingTime"));
            int numberOfGuests = (Integer) bookingData.get("numberOfGuests");
            String notes = (String) bookingData.get("notes");
            
            Booking booking = bookingService.createBookingWithUserInfo(userName, userEmail, userPhone,
                                                                       restaurantId, tableId, bookingTime, 
                                                                       numberOfGuests, notes);
            return ResponseEntity.status(HttpStatus.CREATED).body(booking);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Booking> updateBooking(@PathVariable Long id, @RequestBody Booking booking) {
        try {
            Booking updatedBooking = bookingService.updateBooking(id, booking);
            return ResponseEntity.ok(updatedBooking);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<Booking> updateBookingStatus(@PathVariable Long id, @RequestBody Map<String, String> statusData) {
        try {
            String status = statusData.get("status");
            Booking updatedBooking = bookingService.updateBookingStatus(id, status);
            return ResponseEntity.ok(updatedBooking);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBooking(@PathVariable Long id) {
        try {
            bookingService.deleteBooking(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    // Availability endpoints
    @GetMapping("/availability/table/{tableId}")
    public ResponseEntity<Boolean> checkTableAvailability(
            @PathVariable Long tableId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime bookingTime) {
        boolean available = bookingService.isTableAvailable(tableId, bookingTime);
        return ResponseEntity.ok(available);
    }

    @GetMapping("/availability/restaurant/{restaurantId}")
    public ResponseEntity<Boolean> checkRestaurantAvailability(
            @PathVariable Long restaurantId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime bookingTime,
            @RequestParam int numberOfGuests) {
        boolean available = bookingService.isRestaurantAvailable(restaurantId, bookingTime, numberOfGuests);
        return ResponseEntity.ok(available);
    }

    @GetMapping("/available-tables/{restaurantId}")
    public ResponseEntity<List<RestaurantTable>> getAvailableTables(
            @PathVariable Long restaurantId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime bookingTime) {
        List<RestaurantTable> tables = bookingService.getAvailableTables(restaurantId, bookingTime);
        return ResponseEntity.ok(tables);
    }

    @GetMapping("/available-times/{restaurantId}")
    public ResponseEntity<List<LocalDateTime>> getAvailableTimeSlots(
            @PathVariable Long restaurantId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startTime,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endTime) {
        List<LocalDateTime> timeSlots = bookingService.getAvailableTimeSlots(restaurantId, startTime, endTime);
        return ResponseEntity.ok(timeSlots);
    }

    // Status management endpoints
    @PutMapping("/{id}/confirm")
    public ResponseEntity<Booking> confirmBooking(@PathVariable Long id) {
        try {
            Booking booking = bookingService.confirmBooking(id);
            return ResponseEntity.ok(booking);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}/cancel")
    public ResponseEntity<Booking> cancelBooking(@PathVariable Long id) {
        try {
            Booking booking = bookingService.cancelBooking(id);
            return ResponseEntity.ok(booking);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}/complete")
    public ResponseEntity<Booking> completeBooking(@PathVariable Long id) {
        try {
            Booking booking = bookingService.completeBooking(id);
            return ResponseEntity.ok(booking);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}/no-show")
    public ResponseEntity<Booking> markAsNoShow(@PathVariable Long id) {
        try {
            Booking booking = bookingService.markAsNoShow(id);
            return ResponseEntity.ok(booking);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // Query endpoints
    @GetMapping("/status/{status}")
    public ResponseEntity<List<Booking>> getBookingsByStatus(@PathVariable String status) {
        List<Booking> bookings = bookingService.getBookingsByStatus(status);
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Booking>> getBookingsByUserId(@PathVariable Long userId) {
        List<Booking> bookings = bookingService.getBookingsByUserId(userId);
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/user/email/{email}")
    public ResponseEntity<List<Booking>> getBookingsByUserEmail(@PathVariable String email) {
        List<Booking> bookings = bookingService.getBookingsByUserEmail(email);
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/user/{userId}/upcoming")
    public ResponseEntity<List<Booking>> getUpcomingBookingsByUser(@PathVariable Long userId) {
        List<Booking> bookings = bookingService.getUpcomingBookingsByUser(userId);
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/user/{userId}/past")
    public ResponseEntity<List<Booking>> getPastBookingsByUser(@PathVariable Long userId) {
        List<Booking> bookings = bookingService.getPastBookingsByUser(userId);
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/restaurant/{restaurantId}")
    public ResponseEntity<List<Booking>> getBookingsByRestaurantId(@PathVariable Long restaurantId) {
        List<Booking> bookings = bookingService.getBookingsByRestaurantId(restaurantId);
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/restaurant/{restaurantId}/status/{status}")
    public ResponseEntity<List<Booking>> getBookingsByRestaurantAndStatus(
            @PathVariable Long restaurantId, @PathVariable String status) {
        List<Booking> bookings = bookingService.getBookingsByRestaurantAndStatus(restaurantId, status);
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/table/{tableId}")
    public ResponseEntity<List<Booking>> getBookingsByTableId(@PathVariable Long tableId) {
        List<Booking> bookings = bookingService.getBookingsByTableId(tableId);
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/table/{tableId}/time-range")
    public ResponseEntity<List<Booking>> getBookingsByTableAndTimeRange(
            @PathVariable Long tableId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startTime,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endTime) {
        List<Booking> bookings = bookingService.getBookingsByTableAndTimeRange(tableId, startTime, endTime);
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/time-range")
    public ResponseEntity<List<Booking>> getBookingsByTimeRange(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startTime,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endTime) {
        List<Booking> bookings = bookingService.getBookingsByTimeRange(startTime, endTime);
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/date")
    public ResponseEntity<List<Booking>> getBookingsForDate(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime date) {
        List<Booking> bookings = bookingService.getBookingsForDate(date);
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/today")
    public ResponseEntity<List<Booking>> getTodaysBookings() {
        List<Booking> bookings = bookingService.getTodaysBookings();
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/upcoming")
    public ResponseEntity<List<Booking>> getUpcomingBookings() {
        List<Booking> bookings = bookingService.getUpcomingBookings();
        return ResponseEntity.ok(bookings);
    }

    // Search endpoints
    @GetMapping("/search/user-name/{userName}")
    public ResponseEntity<List<Booking>> searchBookingsByUserName(@PathVariable String userName) {
        List<Booking> bookings = bookingService.searchBookingsByUserName(userName);
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/search/user-email/{userEmail}")
    public ResponseEntity<List<Booking>> searchBookingsByUserEmail(@PathVariable String userEmail) {
        List<Booking> bookings = bookingService.searchBookingsByUserEmail(userEmail);
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/search/notes/{keyword}")
    public ResponseEntity<List<Booking>> searchBookingsByNotes(@PathVariable String keyword) {
        List<Booking> bookings = bookingService.searchBookingsByNotes(keyword);
        return ResponseEntity.ok(bookings);
    }

    // Statistics endpoints
    @GetMapping("/count")
    public ResponseEntity<Long> getBookingCount() {
        long count = bookingService.getBookingCount();
        return ResponseEntity.ok(count);
    }

    @GetMapping("/count/status/{status}")
    public ResponseEntity<Long> getBookingCountByStatus(@PathVariable String status) {
        long count = bookingService.getBookingCountByStatus(status);
        return ResponseEntity.ok(count);
    }

    @GetMapping("/count/restaurant/{restaurantId}")
    public ResponseEntity<Long> getBookingCountByRestaurant(@PathVariable Long restaurantId) {
        long count = bookingService.getBookingCountByRestaurant(restaurantId);
        return ResponseEntity.ok(count);
    }

    @GetMapping("/count/user/{userId}")
    public ResponseEntity<Long> getBookingCountByUser(@PathVariable Long userId) {
        long count = bookingService.getBookingCountByUser(userId);
        return ResponseEntity.ok(count);
    }

    @GetMapping("/guests/restaurant/{restaurantId}")
    public ResponseEntity<Integer> getTotalGuestsAtTime(
            @PathVariable Long restaurantId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime bookingTime) {
        int totalGuests = bookingService.getTotalGuestsAtTime(restaurantId, bookingTime);
        return ResponseEntity.ok(totalGuests);
    }

    @GetMapping("/guests/table/{tableId}")
    public ResponseEntity<Integer> getTotalGuestsForTable(
            @PathVariable Long tableId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime bookingTime) {
        int totalGuests = bookingService.getTotalGuestsForTable(tableId, bookingTime);
        return ResponseEntity.ok(totalGuests);
    }
}