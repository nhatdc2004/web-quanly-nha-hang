package com.manage.restaurant.service;

import com.manage.restaurant.model.Booking;
import com.manage.restaurant.model.User;
import com.manage.restaurant.model.Restaurant;
import com.manage.restaurant.model.RestaurantTable;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface BookingService {

    // Basic CRUD operations
    List<Booking> getAllBookings();
    Optional<Booking> getBookingById(Long id);
    Booking saveBooking(Booking booking);
    Booking updateBooking(Long id, Booking booking);
    void deleteBooking(Long id);

    // Booking creation
    Booking createBooking(Long userId, Long restaurantId, Long tableId, 
                         LocalDateTime bookingTime, int numberOfGuests, String notes);
    Booking createBookingWithUserInfo(String userName, String userEmail, String userPhone,
                                     Long restaurantId, Long tableId, LocalDateTime bookingTime, 
                                     int numberOfGuests, String notes);

    // Availability checking
    boolean isTableAvailable(Long tableId, LocalDateTime bookingTime);
    boolean isRestaurantAvailable(Long restaurantId, LocalDateTime bookingTime, int numberOfGuests);
    List<RestaurantTable> getAvailableTables(Long restaurantId, LocalDateTime bookingTime);
    List<LocalDateTime> getAvailableTimeSlots(Long restaurantId, LocalDateTime startTime, LocalDateTime endTime);

    // Status management
    Booking updateBookingStatus(Long id, String status);
    List<Booking> getBookingsByStatus(String status);

    // User operations
    List<Booking> getBookingsByUser(User user);
    List<Booking> getBookingsByUserId(Long userId);
    List<Booking> getBookingsByUserEmail(String email);
    List<Booking> getUpcomingBookingsByUser(Long userId);
    List<Booking> getPastBookingsByUser(Long userId);

    // Restaurant operations
    List<Booking> getBookingsByRestaurant(Restaurant restaurant);
    List<Booking> getBookingsByRestaurantId(Long restaurantId);
    List<Booking> getBookingsByRestaurantAndStatus(Long restaurantId, String status);

    // Table operations
    List<Booking> getBookingsByTable(RestaurantTable table);
    List<Booking> getBookingsByTableId(Long tableId);
    List<Booking> getBookingsByTableAndTimeRange(Long tableId, LocalDateTime startTime, LocalDateTime endTime);

    // Time-based operations
    List<Booking> getBookingsByTimeRange(LocalDateTime startTime, LocalDateTime endTime);
    List<Booking> getBookingsForDate(LocalDateTime date);
    List<Booking> getTodaysBookings();
    List<Booking> getUpcomingBookings();

    // Booking processing
    Booking confirmBooking(Long id);
    Booking cancelBooking(Long id);
    Booking completeBooking(Long id);
    Booking markAsNoShow(Long id);

    // Statistics and reporting
    long getBookingCount();
    long getBookingCountByStatus(String status);
    long getBookingCountByRestaurant(Long restaurantId);
    long getBookingCountByUser(Long userId);
    int getTotalGuestsAtTime(Long restaurantId, LocalDateTime bookingTime);
    int getTotalGuestsForTable(Long tableId, LocalDateTime bookingTime);

    // Search operations
    List<Booking> searchBookingsByUserName(String userName);
    List<Booking> searchBookingsByUserEmail(String userEmail);
    List<Booking> searchBookingsByNotes(String keyword);
}