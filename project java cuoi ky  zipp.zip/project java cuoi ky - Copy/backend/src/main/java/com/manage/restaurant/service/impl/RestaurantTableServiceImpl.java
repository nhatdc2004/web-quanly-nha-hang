package com.manage.restaurant.service.impl;

import com.manage.restaurant.model.RestaurantTable;
import com.manage.restaurant.model.Restaurant;
import com.manage.restaurant.repository.RestaurantTableRepository;
import com.manage.restaurant.repository.RestaurantRepository;
import com.manage.restaurant.repository.BookingRepository;
import com.manage.restaurant.service.RestaurantTableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class RestaurantTableServiceImpl implements RestaurantTableService {

    @Autowired
    private RestaurantTableRepository restaurantTableRepository;
    
    @Autowired
    private RestaurantRepository restaurantRepository;
    
    @Autowired
    private BookingRepository bookingRepository;

    @Override
    public List<RestaurantTable> getAllTables() {
        return restaurantTableRepository.findAll();
    }

    @Override
    public Optional<RestaurantTable> getTableById(Long id) {
        return restaurantTableRepository.findById(id);
    }

    @Override
    public RestaurantTable saveTable(RestaurantTable table) {
        return restaurantTableRepository.save(table);
    }

    @Override
    public RestaurantTable updateTable(Long id, RestaurantTable table) {
        if (restaurantTableRepository.existsById(id)) {
            table.setId(id);
            return restaurantTableRepository.save(table);
        }
        throw new RuntimeException("Table not found with id: " + id);
    }

    @Override
    public void deleteTable(Long id) {
        restaurantTableRepository.deleteById(id);
    }

    @Override
    public List<RestaurantTable> getTablesByRestaurant(Restaurant restaurant) {
        return restaurantTableRepository.findByRestaurant(restaurant);
    }

    @Override
    public List<RestaurantTable> getTablesByRestaurantId(Long restaurantId) {
        return restaurantTableRepository.findByRestaurantId(restaurantId);
    }

    @Override
    public Optional<RestaurantTable> getTableByRestaurantAndTableNumber(Long restaurantId, int tableNumber) {
        return restaurantTableRepository.findByRestaurantIdAndTableNumber(restaurantId, String.valueOf(tableNumber));
    }

    @Override
    public List<RestaurantTable> getTablesByStatus(String status) {
        return restaurantTableRepository.findByStatus(status);
    }

    @Override
    public List<RestaurantTable> getTablesByRestaurantAndStatus(Long restaurantId, String status) {
        return restaurantTableRepository.findByRestaurantIdAndStatus(restaurantId, status);
    }

    @Override
    public RestaurantTable updateTableStatus(Long id, String status) {
        Optional<RestaurantTable> tableOpt = restaurantTableRepository.findById(id);
        if (tableOpt.isPresent()) {
            RestaurantTable table = tableOpt.get();
            table.setStatus(status);
            return restaurantTableRepository.save(table);
        }
        throw new RuntimeException("Table not found with id: " + id);
    }

    @Override
    public List<RestaurantTable> getTablesByCapacity(int capacity) {
        return restaurantTableRepository.findByCapacity(Integer.valueOf(capacity));
    }

    @Override
    public List<RestaurantTable> getTablesByMinimumCapacity(int minCapacity) {
        return restaurantTableRepository.findByCapacityGreaterThanEqual(Integer.valueOf(minCapacity));
    }

    @Override
    public List<RestaurantTable> getTablesByRestaurantAndCapacity(Long restaurantId, int capacity) {
        return restaurantTableRepository.findByRestaurantIdAndCapacity(restaurantId, Integer.valueOf(capacity));
    }

    @Override
    public List<RestaurantTable> getTablesByRestaurantAndMinimumCapacity(Long restaurantId, int minCapacity) {
        return restaurantTableRepository.findByRestaurantIdAndCapacityGreaterThanEqual(restaurantId, Integer.valueOf(minCapacity));
    }

    @Override
    public List<RestaurantTable> getAvailableTablesByRestaurant(Long restaurantId) {
        return restaurantTableRepository.findAvailableTablesByRestaurant(restaurantId);
    }

    @Override
    public List<RestaurantTable> getAvailableTablesByRestaurantAndCapacity(Long restaurantId, int minCapacity) {
        return restaurantTableRepository.findAvailableTablesByRestaurantAndCapacity(restaurantId, Integer.valueOf(minCapacity));
    }

    @Override
    public boolean isTableAvailable(Long tableId, LocalDateTime bookingTime) {
        // Check if there's any booking for this table at the same time (within 2 hours)
        LocalDateTime startTime = bookingTime.minusHours(2);
        LocalDateTime endTime = bookingTime.plusHours(2);
        
        Optional<RestaurantTable> tableOpt = restaurantTableRepository.findById(tableId);
        if (!tableOpt.isPresent()) {
            return false;
        }
        
        return bookingRepository.findByTableAndBookingTimeBetween(tableOpt.get(), startTime, endTime).isEmpty();
    }

    @Override
    public RestaurantTable createTable(Long restaurantId, String tableNumber, int capacity, String status) {
        Optional<Restaurant> restaurantOpt = restaurantRepository.findById(restaurantId);
        if (!restaurantOpt.isPresent()) {
            throw new RuntimeException("Restaurant not found with id: " + restaurantId);
        }
        
        if (existsByRestaurantAndTableNumber(restaurantId, tableNumber)) {
            throw new RuntimeException("Table number already exists in this restaurant: " + tableNumber);
        }
        
        RestaurantTable table = new RestaurantTable();
        table.setRestaurant(restaurantOpt.get());
        table.setTableNumber(tableNumber);
        table.setCapacity(capacity);
        table.setStatus(status);
        
        return restaurantTableRepository.save(table);
    }

    @Override
    public RestaurantTable updateTableInfo(Long id, String tableNumber, int capacity, String status) {
        Optional<RestaurantTable> tableOpt = restaurantTableRepository.findById(id);
        if (tableOpt.isPresent()) {
            RestaurantTable table = tableOpt.get();
            
            // Check if table number is being changed and if new table number already exists
            if (!table.getTableNumber().equals(tableNumber) && 
                existsByRestaurantAndTableNumber(table.getRestaurant().getId(), tableNumber)) {
                throw new RuntimeException("Table number already exists in this restaurant: " + tableNumber);
            }
            
            table.setTableNumber(tableNumber);
            table.setCapacity(capacity);
            table.setStatus(status);
            
            return restaurantTableRepository.save(table);
        }
        throw new RuntimeException("Table not found with id: " + id);
    }

    @Override
    public long getTableCountByRestaurant(Long restaurantId) {
        return restaurantTableRepository.countByRestaurantId(restaurantId);
    }

    @Override
    public int getTotalCapacityByRestaurant(Long restaurantId) {
        return restaurantTableRepository.getTotalCapacityByRestaurant(restaurantId);
    }

    @Override
    public long getAvailableTableCount(Long restaurantId) {
        return getAvailableTablesByRestaurant(restaurantId).size();
    }

    @Override
    public long getTableCountByStatus(String status) {
        return restaurantTableRepository.countByStatus(status);
    }

    @Override
    public List<RestaurantTable> searchTablesByRestaurantName(String restaurantName) {
        return restaurantTableRepository.findByRestaurantNameContainingIgnoreCase(restaurantName);
    }

    @Override
    public Optional<RestaurantTable> findTableByRestaurantAndNumber(Long restaurantId, int tableNumber) {
        return restaurantTableRepository.findByRestaurantIdAndTableNumber(restaurantId, String.valueOf(tableNumber));
    }

    @Override
    public boolean existsByRestaurantAndTableNumber(Long restaurantId, String tableNumber) {
        return restaurantTableRepository.existsByRestaurantIdAndTableNumber(restaurantId, tableNumber);
    }

    @Override
    public List<RestaurantTable> getAvailableTablesByTimeRange(Long restaurantId, LocalDateTime startTime, LocalDateTime endTime) {
        // Implementation for getting available tables by time range
        return restaurantTableRepository.findByRestaurantIdAndStatus(restaurantId, "AVAILABLE");
    }

    @Override
    public RestaurantTable reserveTable(Long tableId, LocalDateTime reservationTime, int duration) {
        Optional<RestaurantTable> tableOpt = restaurantTableRepository.findById(tableId);
        if (tableOpt.isPresent()) {
            RestaurantTable table = tableOpt.get();
            table.setStatus("RESERVED");
            return restaurantTableRepository.save(table);
        }
        throw new RuntimeException("Table not found with id: " + tableId);
    }

    @Override
    public RestaurantTable cancelReservation(Long tableId) {
        Optional<RestaurantTable> tableOpt = restaurantTableRepository.findById(tableId);
        if (tableOpt.isPresent()) {
            RestaurantTable table = tableOpt.get();
            table.setStatus("AVAILABLE");
            return restaurantTableRepository.save(table);
        }
        throw new RuntimeException("Table not found with id: " + tableId);
    }

    @Override
    public java.util.Map<String, Object> getTableStatistics(Long restaurantId) {
        java.util.Map<String, Object> statistics = new java.util.HashMap<>();
        statistics.put("totalTables", getTableCountByRestaurant(restaurantId));
        statistics.put("availableTables", getAvailableTableCount(restaurantId));
        statistics.put("totalCapacity", getTotalCapacityByRestaurant(restaurantId));
        return statistics;
    }

    @Override
    public Optional<RestaurantTable> findNearestAvailableTable(Long restaurantId, int requiredCapacity, LocalDateTime preferredTime) {
        List<RestaurantTable> availableTables = getAvailableTablesByRestaurantAndCapacity(restaurantId, requiredCapacity);
        return availableTables.stream().findFirst();
    }

    @Override
    public List<RestaurantTable> bulkUpdateTables(List<java.util.Map<String, Object>> tablesData) {
        List<RestaurantTable> updatedTables = new java.util.ArrayList<>();
        for (java.util.Map<String, Object> tableData : tablesData) {
            Long tableId = Long.valueOf(tableData.get("id").toString());
            Optional<RestaurantTable> tableOpt = restaurantTableRepository.findById(tableId);
            if (tableOpt.isPresent()) {
                RestaurantTable table = tableOpt.get();
                if (tableData.containsKey("status")) {
                    table.setStatus(tableData.get("status").toString());
                }
                updatedTables.add(restaurantTableRepository.save(table));
            }
        }
        return updatedTables;
    }

    @Override
    public List<java.util.Map<String, Object>> getTableUsageHistory(Long tableId, LocalDateTime fromDate, LocalDateTime toDate) {
        // Basic implementation - in a real application, this would query a usage history table
        List<java.util.Map<String, Object>> history = new java.util.ArrayList<>();
        java.util.Map<String, Object> usage = new java.util.HashMap<>();
        usage.put("tableId", tableId);
        usage.put("date", fromDate);
        usage.put("status", "Used");
        history.add(usage);
        return history;
    }

    @Override
    public boolean existsByRestaurantAndTableNumber(Long restaurantId, int tableNumber) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'existsByRestaurantAndTableNumber'");
    }


}