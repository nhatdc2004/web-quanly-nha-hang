package com.manage.restaurant.controller;

import com.manage.restaurant.model.Restaurant;
import com.manage.restaurant.service.RestaurantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/restaurants")
@CrossOrigin(origins = "*")
public class RestaurantController {

    @Autowired
    private RestaurantService restaurantService;

    @GetMapping
    public ResponseEntity<List<Restaurant>> getAllRestaurants() {
        List<Restaurant> restaurants = restaurantService.getAllRestaurants();
        return ResponseEntity.ok(restaurants);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Restaurant> getRestaurantById(@PathVariable Long id) {
        Optional<Restaurant> restaurant = restaurantService.getRestaurantById(id);
        return restaurant.map(ResponseEntity::ok)
                        .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Restaurant> createRestaurant(@RequestBody Restaurant restaurant) {
        try {
            Restaurant savedRestaurant = restaurantService.saveRestaurant(restaurant);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedRestaurant);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }

    @PostMapping("/create")
    public ResponseEntity<Restaurant> createRestaurantWithInfo(@RequestBody Map<String, String> restaurantData) {
        try {
            String name = restaurantData.get("name");
            String address = restaurantData.get("address");
            String phoneNumber = restaurantData.get("phoneNumber");
            
            Restaurant restaurant = restaurantService.createRestaurant(name, address, phoneNumber);
            return ResponseEntity.status(HttpStatus.CREATED).body(restaurant);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Restaurant> updateRestaurant(@PathVariable Long id, @RequestBody Restaurant restaurant) {
        try {
            Restaurant updatedRestaurant = restaurantService.updateRestaurant(id, restaurant);
            return ResponseEntity.ok(updatedRestaurant);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}/info")
    public ResponseEntity<Restaurant> updateRestaurantInfo(@PathVariable Long id, @RequestBody Map<String, String> restaurantData) {
        try {
            String name = restaurantData.get("name");
            String address = restaurantData.get("address");
            String phoneNumber = restaurantData.get("phoneNumber");
            
            Restaurant updatedRestaurant = restaurantService.updateRestaurantInfo(id, name, address, phoneNumber);
            return ResponseEntity.ok(updatedRestaurant);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRestaurant(@PathVariable Long id) {
        try {
            restaurantService.deleteRestaurant(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/name/{name}")
    public ResponseEntity<Restaurant> getRestaurantByName(@PathVariable String name) {
        Optional<Restaurant> restaurant = restaurantService.getRestaurantByName(name);
        return restaurant.map(ResponseEntity::ok)
                        .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/phone/{phoneNumber}")
    public ResponseEntity<Restaurant> getRestaurantByPhoneNumber(@PathVariable String phoneNumber) {
        Optional<Restaurant> restaurant = restaurantService.getRestaurantByPhoneNumber(phoneNumber);
        return restaurant.map(ResponseEntity::ok)
                        .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/address/{address}")
    public ResponseEntity<List<Restaurant>> getRestaurantsByAddress(@PathVariable String address) {
        List<Restaurant> restaurants = restaurantService.getRestaurantsByAddress(address);
        return ResponseEntity.ok(restaurants);
    }

    @GetMapping("/search/name/{name}")
    public ResponseEntity<List<Restaurant>> searchRestaurantsByName(@PathVariable String name) {
        List<Restaurant> restaurants = restaurantService.searchRestaurantsByName(name);
        return ResponseEntity.ok(restaurants);
    }

    @GetMapping("/search/address/{address}")
    public ResponseEntity<List<Restaurant>> searchRestaurantsByAddress(@PathVariable String address) {
        List<Restaurant> restaurants = restaurantService.searchRestaurantsByAddress(address);
        return ResponseEntity.ok(restaurants);
    }

    @GetMapping("/search/{keyword}")
    public ResponseEntity<List<Restaurant>> searchRestaurants(@PathVariable String keyword) {
        List<Restaurant> restaurants = restaurantService.searchRestaurants(keyword);
        return ResponseEntity.ok(restaurants);
    }

    @GetMapping("/exists/name/{name}")
    public ResponseEntity<Boolean> checkNameExists(@PathVariable String name) {
        boolean exists = restaurantService.existsByName(name);
        return ResponseEntity.ok(exists);
    }

    @GetMapping("/exists/phone/{phoneNumber}")
    public ResponseEntity<Boolean> checkPhoneExists(@PathVariable String phoneNumber) {
        boolean exists = restaurantService.existsByPhoneNumber(phoneNumber);
        return ResponseEntity.ok(exists);
    }

    @GetMapping("/count")
    public ResponseEntity<Long> getTotalRestaurantCount() {
        long count = restaurantService.getTotalRestaurantCount();
        return ResponseEntity.ok(count);
    }
}