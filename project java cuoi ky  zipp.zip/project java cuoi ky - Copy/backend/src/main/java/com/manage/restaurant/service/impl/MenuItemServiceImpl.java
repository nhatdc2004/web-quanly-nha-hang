package com.manage.restaurant.service.impl;

import com.manage.restaurant.model.MenuItem;
import com.manage.restaurant.repository.MenuItemRepository;
import com.manage.restaurant.service.MenuItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class MenuItemServiceImpl implements MenuItemService {

    @Autowired
    private MenuItemRepository menuItemRepository;

    @Override
    public List<MenuItem> getAllMenuItems() {
        return menuItemRepository.findAll();
    }

    @Override
    public List<MenuItem> getAvailableMenuItems() {
        return menuItemRepository.findByAvailableTrue();
    }

    @Override
    public Optional<MenuItem> getMenuItemById(Long id) {
        return menuItemRepository.findById(id);
    }

    @Override
    public MenuItem saveMenuItem(MenuItem menuItem) {
        return menuItemRepository.save(menuItem);
    }

    @Override
    public MenuItem updateMenuItem(Long id, MenuItem menuItem) {
        if (menuItemRepository.existsById(id)) {
            menuItem.setId(id);
            return menuItemRepository.save(menuItem);
        }
        throw new RuntimeException("MenuItem not found with id: " + id);
    }

    @Override
    public void deleteMenuItem(Long id) {
        menuItemRepository.deleteById(id);
    }

    @Override
    public List<MenuItem> getMenuItemsByCategory(String category) {
        return menuItemRepository.findByCategoryAndAvailableTrue(category);
    }

    @Override
    public List<String> getAllCategories() {
        return menuItemRepository.findDistinctCategories();
    }

    @Override
    public List<MenuItem> searchMenuItemsByName(String name) {
        return menuItemRepository.findByNameContainingIgnoreCaseAndAvailableTrue(name);
    }

    @Override
    public List<MenuItem> getMenuItemsByPriceRange(BigDecimal minPrice, BigDecimal maxPrice) {
        return menuItemRepository.findByPriceBetweenAndAvailableTrue(minPrice, maxPrice);
    }

    @Override
    public MenuItem toggleAvailability(Long id) {
        Optional<MenuItem> menuItemOpt = menuItemRepository.findById(id);
        if (menuItemOpt.isPresent()) {
            MenuItem menuItem = menuItemOpt.get();
            menuItem.setAvailable(!menuItem.getAvailable());
            return menuItemRepository.save(menuItem);
        }
        throw new RuntimeException("MenuItem not found with id: " + id);
    }

    @Override
    public void setAvailability(Long id, boolean available) {
        Optional<MenuItem> menuItemOpt = menuItemRepository.findById(id);
        if (menuItemOpt.isPresent()) {
            MenuItem menuItem = menuItemOpt.get();
            menuItem.setAvailable(available);
            menuItemRepository.save(menuItem);
        } else {
            throw new RuntimeException("MenuItem not found with id: " + id);
        }
    }

    @Override
    public List<MenuItem> saveAllMenuItems(List<MenuItem> menuItems) {
        return menuItemRepository.saveAll(menuItems);
    }

    @Override
    public List<MenuItem> saveMenuItemsBulk(List<MenuItem> menuItems) {
        return menuItemRepository.saveAll(menuItems);
    }

    @Override
    public List<MenuItem> initializeDefaultMenuItems() {
        if (menuItemRepository.count() == 0) {
            List<MenuItem> defaultItems = Arrays.asList(
                new MenuItem("Margherita Pizzaa", "Classic pizza with tomato sauce, mozzarella, and basil", new BigDecimal("12.99"), "Pizza"),
                new MenuItem("Caesar Salad", "Fresh romaine lettuce with Caesar dressing, croutons, and parmesan", new BigDecimal("8.99"), "Salad"),
                new MenuItem("Grilled Chicken", "Tender grilled chicken breast with herbs and spices", new BigDecimal("15.99"), "Main Course"),
                new MenuItem("Chocolate Cake", "Rich chocolate cake with chocolate frosting", new BigDecimal("6.99"), "Dessert"),
                new MenuItem("Coffee", "Freshly brewed coffee", new BigDecimal("2.99"), "Beverage")
            );
            return menuItemRepository.saveAll(defaultItems);
        }
        return getAllMenuItems();
    }
    
    @Override
    public void deleteAllMenuItemsExceptPhoBo() {
        // Find all menu items except "Phở Bò Tái"
        List<MenuItem> allItems = menuItemRepository.findAll();
        List<MenuItem> itemsToDelete = allItems.stream()
            .filter(item -> !item.getName().equals("Phở Bò"))
            .collect(Collectors.toList());
        
        // Delete the filtered items
        if (!itemsToDelete.isEmpty()) {
            menuItemRepository.deleteAll(itemsToDelete);
        }
    }
}