package com.manage.restaurant.repository;

import com.manage.restaurant.model.ContactMessage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ContactMessageRepository extends JpaRepository<ContactMessage, Long> {

    // Find messages by status
    List<ContactMessage> findByStatus(ContactMessage.MessageStatus status);

    // Find messages by email
    List<ContactMessage> findByEmail(String email);

    // Find messages created between dates
    List<ContactMessage> findByCreatedAtBetween(LocalDateTime startDate, LocalDateTime endDate);

    // Find recent messages (last 7 days)
    @Query("SELECT c FROM ContactMessage c WHERE c.createdAt >= :since ORDER BY c.createdAt DESC")
    List<ContactMessage> findRecentMessages(@Param("since") LocalDateTime since);

    // Count messages by status
    long countByStatus(ContactMessage.MessageStatus status);

    // Find unread messages
    List<ContactMessage> findByStatusOrderByCreatedAtDesc(ContactMessage.MessageStatus status);

    // Search messages by subject or content
    @Query("SELECT c FROM ContactMessage c WHERE LOWER(c.subject) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(c.message) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<ContactMessage> searchByKeyword(@Param("keyword") String keyword);

    // Find messages by subject or message containing keyword (case insensitive)
    List<ContactMessage> findBySubjectContainingIgnoreCaseOrMessageContainingIgnoreCase(String subject, String message);
    
    // Find messages created after a specific date
    List<ContactMessage> findByCreatedAtAfter(LocalDateTime date);
}