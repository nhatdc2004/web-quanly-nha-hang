package com.manage.restaurant.repository;

import com.manage.restaurant.model.RestaurantTable;
import com.manage.restaurant.model.Restaurant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RestaurantTableRepository extends JpaRepository<RestaurantTable, Long> {

    // Find tables by restaurant
    List<RestaurantTable> findByRestaurant(Restaurant restaurant);

    // Find tables by restaurant ID
    List<RestaurantTable> findByRestaurantId(Long restaurantId);

    // Find table by restaurant and table number
    Optional<RestaurantTable> findByRestaurantAndTableNumber(Restaurant restaurant, String tableNumber);

    // Find table by restaurant ID and table number
    Optional<RestaurantTable> findByRestaurantIdAndTableNumber(Long restaurantId, String tableNumber);

    // Find tables by status
    List<RestaurantTable> findByStatus(String status);

    // Find tables by restaurant and status
    List<RestaurantTable> findByRestaurantAndStatus(Restaurant restaurant, String status);

    // Find tables by restaurant ID and status
    List<RestaurantTable> findByRestaurantIdAndStatus(Long restaurantId, String status);

    // Find tables by capacity
    List<RestaurantTable> findByCapacity(Integer capacity);

    // Find tables by minimum capacity
    List<RestaurantTable> findByCapacityGreaterThanEqual(Integer minCapacity);

    // Find tables by restaurant and capacity
    List<RestaurantTable> findByRestaurantIdAndCapacity(Long restaurantId, Integer capacity);

    // Find tables by restaurant and minimum capacity
    List<RestaurantTable> findByRestaurantIdAndCapacityGreaterThanEqual(Long restaurantId, Integer minCapacity);

    // Find available tables for a restaurant
    @Query("SELECT t FROM RestaurantTable t WHERE t.restaurant.id = :restaurantId AND t.status = 'AVAILABLE'")
    List<RestaurantTable> findAvailableTablesByRestaurant(@Param("restaurantId") Long restaurantId);

    // Find available tables by restaurant and minimum capacity
    @Query("SELECT t FROM RestaurantTable t WHERE t.restaurant.id = :restaurantId AND t.status = 'AVAILABLE' AND t.capacity >= :minCapacity")
    List<RestaurantTable> findAvailableTablesByRestaurantAndCapacity(@Param("restaurantId") Long restaurantId, @Param("minCapacity") Integer minCapacity);

    // Get total capacity for a restaurant
    @Query("SELECT SUM(t.capacity) FROM RestaurantTable t WHERE t.restaurant.id = :restaurantId")
    Integer getTotalCapacityByRestaurant(@Param("restaurantId") Long restaurantId);

    // Count tables by restaurant
    long countByRestaurantId(Long restaurantId);

    // Count available tables by restaurant
    @Query("SELECT COUNT(t) FROM RestaurantTable t WHERE t.restaurant.id = :restaurantId AND t.status = 'AVAILABLE'")
    long countAvailableTablesByRestaurant(@Param("restaurantId") Long restaurantId);

    // Count tables by status
    long countByStatus(String status);

    // Search tables by restaurant name
    @Query("SELECT t FROM RestaurantTable t WHERE LOWER(t.restaurant.name) LIKE LOWER(CONCAT('%', :restaurantName, '%'))")
    List<RestaurantTable> findByRestaurantNameContainingIgnoreCase(@Param("restaurantName") String restaurantName);

    // Check if table exists by restaurant and table number
    boolean existsByRestaurantIdAndTableNumber(Long restaurantId, String tableNumber);
}