package com.manage.restaurant.service;

import com.manage.restaurant.model.Order;
import com.manage.restaurant.model.User;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.math.BigDecimal;

public interface OrderService {

    // Basic CRUD operations
    List<Order> getAllOrders();
    Optional<Order> getOrderById(Long id);
    Order saveOrder(Order order);
    Order updateOrder(Long id, Order order);
    void deleteOrder(Long id);

    // Order creation with user info
    Order createOrderWithUserInfo(Order order, String name, String email, String phoneNumber);

    // Status management
    Order updateOrderStatus(Long id, Order.OrderStatus status);
    List<Order> getOrdersByStatus(Order.OrderStatus status);

    // User operations
    List<Order> getOrdersByUser(User user);
    List<Order> getOrdersByUserId(Long userId);
    List<Order> getOrdersByUserEmail(String email);

    // Date and time operations
    List<Order> getOrdersByDateRange(LocalDateTime startDate, LocalDateTime endDate);
    List<Order> getRecentOrders(int hours);

    // Order type operations
    List<Order> getOrdersByType(Order.OrderType orderType);

    // Statistics and reporting
    long getOrderCountByStatus(Order.OrderStatus status);
    BigDecimal getTotalRevenueByDateRange(LocalDateTime startDate, LocalDateTime endDate);
    BigDecimal calculateOrderTotal(Order order);

    // Order processing
    Order confirmOrder(Long id);
    Order cancelOrder(Long id);
    Order completeOrder(Long id);
}