package com.manage.restaurant.repository;

import com.manage.restaurant.model.Booking;
import com.manage.restaurant.model.User;
import com.manage.restaurant.model.Restaurant;
import com.manage.restaurant.model.RestaurantTable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

    // Find bookings by user
    List<Booking> findByUser(User user);

    // Find bookings by user ID
    List<Booking> findByUserId(Long userId);

    // Find bookings by restaurant
    List<Booking> findByRestaurant(Restaurant restaurant);

    // Find bookings by restaurant ID
    List<Booking> findByRestaurantId(Long restaurantId);

    // Find bookings by table
    List<Booking> findByTable(RestaurantTable table);

    // Find bookings by table ID
    List<Booking> findByTableId(Long tableId);

    // Find bookings by status
    List<Booking> findByStatus(String status);

    // Find bookings by booking time range
    List<Booking> findByBookingTimeBetween(LocalDateTime startTime, LocalDateTime endTime);

    // Find bookings by user email
    @Query("SELECT b FROM Booking b WHERE b.user.email = :email ORDER BY b.bookingTime DESC")
    List<Booking> findByUserEmail(@Param("email") String email);

    // Find upcoming bookings for a user
    @Query("SELECT b FROM Booking b WHERE b.user.id = :userId AND b.bookingTime >= :currentTime ORDER BY b.bookingTime")
    List<Booking> findUpcomingBookingsByUser(@Param("userId") Long userId, @Param("currentTime") LocalDateTime currentTime);

    // Count bookings at specific time for a table
    @Query("SELECT COUNT(b) FROM Booking b WHERE b.table.id = :tableId AND b.bookingTime = :bookingTime AND b.status IN ('PENDING', 'CONFIRMED')")
    long countBookingsAtTimeForTable(@Param("tableId") Long tableId, @Param("bookingTime") LocalDateTime bookingTime);

    // Get total guests at specific time for a restaurant
    @Query("SELECT SUM(b.numberOfGuests) FROM Booking b WHERE b.restaurant.id = :restaurantId AND b.bookingTime = :bookingTime AND b.status IN ('PENDING', 'CONFIRMED')")
    Integer getTotalGuestsAtTimeForRestaurant(@Param("restaurantId") Long restaurantId, @Param("bookingTime") LocalDateTime bookingTime);

    // Check table availability at specific time
    @Query("SELECT COUNT(b) FROM Booking b WHERE b.table.id = :tableId AND b.bookingTime BETWEEN :startTime AND :endTime AND b.status IN ('PENDING', 'CONFIRMED')")
    long countConflictingBookings(@Param("tableId") Long tableId, @Param("startTime") LocalDateTime startTime, @Param("endTime") LocalDateTime endTime);

    // Find bookings by restaurant and time range
    @Query("SELECT b FROM Booking b WHERE b.restaurant.id = :restaurantId AND b.bookingTime BETWEEN :startTime AND :endTime")
    List<Booking> findByRestaurantAndTimeRange(@Param("restaurantId") Long restaurantId, @Param("startTime") LocalDateTime startTime, @Param("endTime") LocalDateTime endTime);

    // Find bookings by table and time range
    @Query("SELECT b FROM Booking b WHERE b.table.id = :tableId AND b.bookingTime BETWEEN :startTime AND :endTime")
    List<Booking> findByTableAndTimeRange(@Param("tableId") Long tableId, @Param("startTime") LocalDateTime startTime, @Param("endTime") LocalDateTime endTime);

    // Search bookings by user name
    @Query("SELECT b FROM Booking b WHERE LOWER(b.user.name) LIKE LOWER(CONCAT('%', :name, '%'))")
    List<Booking> findByUserNameContainingIgnoreCase(@Param("name") String name);

    // Search bookings by notes
    List<Booking> findByNotesContainingIgnoreCase(String notes);

    // Count bookings by status
    long countByStatus(String status);

    // Count bookings by restaurant
    long countByRestaurantId(Long restaurantId);

    // Count bookings by user
    long countByUserId(Long userId);

    // Get total guests by restaurant
    @Query("SELECT SUM(b.numberOfGuests) FROM Booking b WHERE b.restaurant.id = :restaurantId")
    Integer getTotalGuestsByRestaurant(@Param("restaurantId") Long restaurantId);

    // Get total guests by status
    @Query("SELECT SUM(b.numberOfGuests) FROM Booking b WHERE b.status = :status")
    Integer getTotalGuestsByStatus(@Param("status") String status);

    // Find past bookings by user ID
    List<Booking> findByUserIdAndBookingTimeBefore(Long userId, LocalDateTime dateTime);

    // Find future bookings
    List<Booking> findByBookingTimeAfter(LocalDateTime dateTime);

    // Find bookings by table and booking time range
    List<Booking> findByTableAndBookingTimeBetween(RestaurantTable table, LocalDateTime startTime, LocalDateTime endTime);
}