package com.manage.restaurant.service;

import com.manage.restaurant.model.ContactMessage;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface ContactMessageService {

    // Basic CRUD operations
    List<ContactMessage> getAllContactMessages();
    Optional<ContactMessage> getContactMessageById(Long id);
    ContactMessage saveContactMessage(ContactMessage contactMessage);
    ContactMessage updateContactMessage(Long id, ContactMessage contactMessage);
    void deleteContactMessage(Long id);

    // Message creation
    ContactMessage createContactMessage(String name, String email, String phone, String subject, String message);

    // Status management
    ContactMessage updateMessageStatus(Long id, ContactMessage.MessageStatus status);
    List<ContactMessage> getMessagesByStatus(ContactMessage.MessageStatus status);
    ContactMessage markAsRead(Long id);
    ContactMessage markAsReplied(Long id);
    ContactMessage archiveMessage(Long id);

    // Search and filter operations
    List<ContactMessage> getMessagesByEmail(String email);
    List<ContactMessage> getMessagesByDateRange(LocalDateTime startDate, LocalDateTime endDate);
    List<ContactMessage> getRecentMessages(int days);
    List<ContactMessage> searchMessagesByKeyword(String keyword);

    // Statistics
    long getMessageCountByStatus(ContactMessage.MessageStatus status);
    List<ContactMessage> getUnreadMessages();
    List<ContactMessage> getNewMessages();
    
    // Additional status management
    List<ContactMessage> getInProgressMessages();
    ContactMessage markAsInProgress(Long id);
    List<ContactMessage> getResolvedMessages();
    ContactMessage markAsResolved(Long id);
    
    // Additional statistics
    long getTotalMessageCount();
    long getNewMessageCount();
    long getInProgressMessageCount();
    long getResolvedMessageCount();
}