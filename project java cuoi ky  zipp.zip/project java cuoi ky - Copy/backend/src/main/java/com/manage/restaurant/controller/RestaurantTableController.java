package com.manage.restaurant.controller;

import com.manage.restaurant.model.RestaurantTable;
import com.manage.restaurant.service.RestaurantTableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/tables")
@CrossOrigin(origins = "*")
public class RestaurantTableController {

    @Autowired
    private RestaurantTableService restaurantTableService;

    @GetMapping
    public ResponseEntity<List<RestaurantTable>> getAllTables() {
        List<RestaurantTable> tables = restaurantTableService.getAllTables();
        return ResponseEntity.ok(tables);
    }

    @GetMapping("/{id}")
    public ResponseEntity<RestaurantTable> getTableById(@PathVariable Long id) {
        Optional<RestaurantTable> table = restaurantTableService.getTableById(id);
        return table.map(ResponseEntity::ok)
                   .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<RestaurantTable> createTable(@RequestBody RestaurantTable table) {
        try {
            RestaurantTable savedTable = restaurantTableService.saveTable(table);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedTable);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }

    @PostMapping("/create")
    public ResponseEntity<RestaurantTable> createTableWithInfo(@RequestBody Map<String, Object> tableData) {
        try {
            Long restaurantId = Long.valueOf(tableData.get("restaurantId").toString());
            int tableNumber = (Integer) tableData.get("tableNumber");
            int capacity = (Integer) tableData.get("capacity");
            String status = (String) tableData.getOrDefault("status", "AVAILABLE");
            
            RestaurantTable table = restaurantTableService.createTable(restaurantId, String.valueOf(tableNumber), capacity, status);
            return ResponseEntity.status(HttpStatus.CREATED).body(table);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<RestaurantTable> updateTable(@PathVariable Long id, @RequestBody RestaurantTable table) {
        try {
            RestaurantTable updatedTable = restaurantTableService.updateTable(id, table);
            return ResponseEntity.ok(updatedTable);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}/info")
    public ResponseEntity<RestaurantTable> updateTableInfo(@PathVariable Long id, @RequestBody Map<String, Object> tableData) {
        try {
            int tableNumber = (Integer) tableData.get("tableNumber");
            int capacity = (Integer) tableData.get("capacity");
            String status = (String) tableData.get("status");
            
            RestaurantTable updatedTable = restaurantTableService.updateTableInfo(id, String.valueOf(tableNumber), capacity, status);
            return ResponseEntity.ok(updatedTable);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<RestaurantTable> updateTableStatus(@PathVariable Long id, @RequestBody Map<String, String> statusData) {
        try {
            String status = statusData.get("status");
            RestaurantTable updatedTable = restaurantTableService.updateTableStatus(id, status);
            return ResponseEntity.ok(updatedTable);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTable(@PathVariable Long id) {
        try {
            restaurantTableService.deleteTable(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    // Restaurant-based operations
    @GetMapping("/restaurant/{restaurantId}")
    public ResponseEntity<List<RestaurantTable>> getTablesByRestaurantId(@PathVariable Long restaurantId) {
        List<RestaurantTable> tables = restaurantTableService.getTablesByRestaurantId(restaurantId);
        return ResponseEntity.ok(tables);
    }

    @GetMapping("/restaurant/{restaurantId}/table/{tableNumber}")
    public ResponseEntity<RestaurantTable> getTableByRestaurantAndTableNumber(
            @PathVariable Long restaurantId, @PathVariable int tableNumber) {
        Optional<RestaurantTable> table = restaurantTableService.getTableByRestaurantAndTableNumber(restaurantId, tableNumber);
        return table.map(ResponseEntity::ok)
                   .orElse(ResponseEntity.notFound().build());
    }

    // Status-based operations
    @GetMapping("/status/{status}")
    public ResponseEntity<List<RestaurantTable>> getTablesByStatus(@PathVariable String status) {
        List<RestaurantTable> tables = restaurantTableService.getTablesByStatus(status);
        return ResponseEntity.ok(tables);
    }

    @GetMapping("/restaurant/{restaurantId}/status/{status}")
    public ResponseEntity<List<RestaurantTable>> getTablesByRestaurantAndStatus(
            @PathVariable Long restaurantId, @PathVariable String status) {
        List<RestaurantTable> tables = restaurantTableService.getTablesByRestaurantAndStatus(restaurantId, status);
        return ResponseEntity.ok(tables);
    }

    // Capacity-based operations
    @GetMapping("/capacity/{capacity}")
    public ResponseEntity<List<RestaurantTable>> getTablesByCapacity(@PathVariable int capacity) {
        List<RestaurantTable> tables = restaurantTableService.getTablesByCapacity(capacity);
        return ResponseEntity.ok(tables);
    }

    @GetMapping("/min-capacity/{minCapacity}")
    public ResponseEntity<List<RestaurantTable>> getTablesByMinimumCapacity(@PathVariable int minCapacity) {
        List<RestaurantTable> tables = restaurantTableService.getTablesByMinimumCapacity(minCapacity);
        return ResponseEntity.ok(tables);
    }

    @GetMapping("/restaurant/{restaurantId}/capacity/{capacity}")
    public ResponseEntity<List<RestaurantTable>> getTablesByRestaurantAndCapacity(
            @PathVariable Long restaurantId, @PathVariable int capacity) {
        List<RestaurantTable> tables = restaurantTableService.getTablesByRestaurantAndCapacity(restaurantId, capacity);
        return ResponseEntity.ok(tables);
    }

    @GetMapping("/restaurant/{restaurantId}/min-capacity/{minCapacity}")
    public ResponseEntity<List<RestaurantTable>> getTablesByRestaurantAndMinimumCapacity(
            @PathVariable Long restaurantId, @PathVariable int minCapacity) {
        List<RestaurantTable> tables = restaurantTableService.getTablesByRestaurantAndMinimumCapacity(restaurantId, minCapacity);
        return ResponseEntity.ok(tables);
    }

    // Availability operations
    @GetMapping("/restaurant/{restaurantId}/available")
    public ResponseEntity<List<RestaurantTable>> getAvailableTablesByRestaurant(@PathVariable Long restaurantId) {
        List<RestaurantTable> tables = restaurantTableService.getAvailableTablesByRestaurant(restaurantId);
        return ResponseEntity.ok(tables);
    }

    @GetMapping("/restaurant/{restaurantId}/available/capacity/{minCapacity}")
    public ResponseEntity<List<RestaurantTable>> getAvailableTablesByRestaurantAndCapacity(
            @PathVariable Long restaurantId, @PathVariable int minCapacity) {
        List<RestaurantTable> tables = restaurantTableService.getAvailableTablesByRestaurantAndCapacity(restaurantId, minCapacity);
        return ResponseEntity.ok(tables);
    }

    @GetMapping("/{tableId}/available")
    public ResponseEntity<Boolean> isTableAvailable(
            @PathVariable Long tableId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime bookingTime) {
        boolean available = restaurantTableService.isTableAvailable(tableId, bookingTime);
        return ResponseEntity.ok(available);
    }

    // Search operations
    @GetMapping("/search/restaurant-name/{restaurantName}")
    public ResponseEntity<List<RestaurantTable>> searchTablesByRestaurantName(@PathVariable String restaurantName) {
        List<RestaurantTable> tables = restaurantTableService.searchTablesByRestaurantName(restaurantName);
        return ResponseEntity.ok(tables);
    }

    @GetMapping("/find/restaurant/{restaurantId}/number/{tableNumber}")
    public ResponseEntity<RestaurantTable> findTableByRestaurantAndNumber(
            @PathVariable Long restaurantId, @PathVariable int tableNumber) {
        Optional<RestaurantTable> table = restaurantTableService.findTableByRestaurantAndNumber(restaurantId, tableNumber);
        return table.map(ResponseEntity::ok)
                   .orElse(ResponseEntity.notFound().build());
    }

    // Existence checks
    @GetMapping("/exists/restaurant/{restaurantId}/number/{tableNumber}")
    public ResponseEntity<Boolean> checkTableExists(
            @PathVariable Long restaurantId, @PathVariable int tableNumber) {
        boolean exists = restaurantTableService.existsByRestaurantAndTableNumber(restaurantId, tableNumber);
        return ResponseEntity.ok(exists);
    }

    // Statistics
    @GetMapping("/count/restaurant/{restaurantId}")
    public ResponseEntity<Long> getTableCountByRestaurant(@PathVariable Long restaurantId) {
        long count = restaurantTableService.getTableCountByRestaurant(restaurantId);
        return ResponseEntity.ok(count);
    }

    @GetMapping("/capacity/restaurant/{restaurantId}/total")
    public ResponseEntity<Integer> getTotalCapacityByRestaurant(@PathVariable Long restaurantId) {
        int totalCapacity = restaurantTableService.getTotalCapacityByRestaurant(restaurantId);
        return ResponseEntity.ok(totalCapacity);
    }

    @GetMapping("/count/restaurant/{restaurantId}/available")
    public ResponseEntity<Long> getAvailableTableCount(@PathVariable Long restaurantId) {
        long count = restaurantTableService.getAvailableTableCount(restaurantId);
        return ResponseEntity.ok(count);
    }

    @GetMapping("/count/status/{status}")
    public ResponseEntity<Long> getTableCountByStatus(@PathVariable String status) {
        long count = restaurantTableService.getTableCountByStatus(status);
        return ResponseEntity.ok(count);
    }

    // Thêm method mới: Lấy bàn theo khoảng thời gian có sẵn
    @GetMapping("/restaurant/{restaurantId}/available-time")
    public ResponseEntity<List<RestaurantTable>> getAvailableTablesByTimeRange(
            @PathVariable Long restaurantId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startTime,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endTime) {
        try {
            List<RestaurantTable> tables = restaurantTableService.getAvailableTablesByTimeRange(restaurantId, startTime, endTime);
            return ResponseEntity.ok(tables);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }

    // Thêm method mới: Đặt bàn trước
    @PostMapping("/{tableId}/reserve")
    public ResponseEntity<RestaurantTable> reserveTable(
            @PathVariable Long tableId,
            @RequestBody Map<String, Object> reservationData) {
        try {
            LocalDateTime reservationTime = LocalDateTime.parse(reservationData.get("reservationTime").toString());
            int duration = (Integer) reservationData.get("duration");
            
            RestaurantTable reservedTable = restaurantTableService.reserveTable(tableId, reservationTime, duration);
            return ResponseEntity.ok(reservedTable);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(null);
        }
    }

    // Thêm method mới: Hủy đặt bàn
    @DeleteMapping("/{tableId}/reservation")
    public ResponseEntity<RestaurantTable> cancelReservation(@PathVariable Long tableId) {
        try {
            RestaurantTable table = restaurantTableService.cancelReservation(tableId);
            return ResponseEntity.ok(table);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // Thêm method mới: Lấy thống kê chi tiết của nhà hàng
    @GetMapping("/restaurant/{restaurantId}/statistics")
    public ResponseEntity<Map<String, Object>> getTableStatistics(@PathVariable Long restaurantId) {
        try {
            Map<String, Object> statistics = restaurantTableService.getTableStatistics(restaurantId);
            return ResponseEntity.ok(statistics);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    // Thêm method mới: Tìm bàn gần nhất có sẵn
    @GetMapping("/restaurant/{restaurantId}/nearest-available")
    public ResponseEntity<RestaurantTable> findNearestAvailableTable(
            @PathVariable Long restaurantId,
            @RequestParam int requiredCapacity,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime preferredTime) {
        try {
            Optional<RestaurantTable> table = restaurantTableService.findNearestAvailableTable(restaurantId, requiredCapacity, preferredTime);
            return table.map(ResponseEntity::ok)
                       .orElse(ResponseEntity.notFound().build());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }

    // Thêm method mới: Cập nhật nhiều bàn cùng lúc
    @PutMapping("/bulk-update")
    public ResponseEntity<List<RestaurantTable>> bulkUpdateTables(@RequestBody List<Map<String, Object>> tablesData) {
        try {
            List<RestaurantTable> updatedTables = restaurantTableService.bulkUpdateTables(tablesData);
            return ResponseEntity.ok(updatedTables);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }

    // Thêm method mới: Lấy lịch sử dụng bàn
    @GetMapping("/{tableId}/usage-history")
    public ResponseEntity<List<Map<String, Object>>> getTableUsageHistory(
            @PathVariable Long tableId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDateTime fromDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDateTime toDate) {
        try {
            List<Map<String, Object>> history = restaurantTableService.getTableUsageHistory(tableId, fromDate, toDate);
            return ResponseEntity.ok(history);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }
}