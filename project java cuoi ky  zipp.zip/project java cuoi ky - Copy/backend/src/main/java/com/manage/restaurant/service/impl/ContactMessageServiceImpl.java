package com.manage.restaurant.service.impl;

import com.manage.restaurant.model.ContactMessage;
import com.manage.restaurant.repository.ContactMessageRepository;
import com.manage.restaurant.service.ContactMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class ContactMessageServiceImpl implements ContactMessageService {

    @Autowired
    private ContactMessageRepository contactMessageRepository;

    @Override
    public List<ContactMessage> getAllContactMessages() {
        return contactMessageRepository.findAll();
    }

    @Override
    public Optional<ContactMessage> getContactMessageById(Long id) {
        return contactMessageRepository.findById(id);
    }

    @Override
    public ContactMessage saveContactMessage(ContactMessage message) {
        return contactMessageRepository.save(message);
    }

    @Override
    public ContactMessage updateContactMessage(Long id, ContactMessage message) {
        if (contactMessageRepository.existsById(id)) {
            message.setId(id);
            return contactMessageRepository.save(message);
        }
        throw new RuntimeException("Contact message not found with id: " + id);
    }

    @Override
    public void deleteContactMessage(Long id) {
        contactMessageRepository.deleteById(id);
    }

    @Override
    public ContactMessage createContactMessage(String name, String email, String phone, String subject, String messageText) {
        ContactMessage message = new ContactMessage();
        message.setName(name);
        message.setEmail(email);
        message.setPhone(phone);
        message.setSubject(subject);
        message.setMessage(messageText);
        message.setStatus(ContactMessage.MessageStatus.NEW);
        
        return contactMessageRepository.save(message);
    }

    @Override
    public ContactMessage updateMessageStatus(Long id, ContactMessage.MessageStatus status) {
        Optional<ContactMessage> messageOpt = contactMessageRepository.findById(id);
        if (messageOpt.isPresent()) {
            ContactMessage message = messageOpt.get();
            message.setStatus(status);
            return contactMessageRepository.save(message);
        }
        throw new RuntimeException("Contact message not found with id: " + id);
    }

    @Override
    public List<ContactMessage> getMessagesByStatus(ContactMessage.MessageStatus status) {
        return contactMessageRepository.findByStatus(status);
    }

    @Override
    public List<ContactMessage> getMessagesByEmail(String email) {
        return contactMessageRepository.findByEmail(email);
    }

    @Override
    public List<ContactMessage> getMessagesByDateRange(LocalDateTime startDate, LocalDateTime endDate) {
        return contactMessageRepository.findByCreatedAtBetween(startDate, endDate);
    }

    @Override
    public List<ContactMessage> searchMessagesByKeyword(String keyword) {
        return contactMessageRepository.findBySubjectContainingIgnoreCaseOrMessageContainingIgnoreCase(keyword, keyword);
    }

    @Override
    public List<ContactMessage> getNewMessages() {
        return getMessagesByStatus(ContactMessage.MessageStatus.NEW);
    }

    @Override
    public List<ContactMessage> getInProgressMessages() {
        return getMessagesByStatus(ContactMessage.MessageStatus.IN_PROGRESS);
    }

    @Override
    public List<ContactMessage> getResolvedMessages() {
        return getMessagesByStatus(ContactMessage.MessageStatus.RESOLVED);
    }

    @Override
    public ContactMessage markAsInProgress(Long id) {
        return updateMessageStatus(id, ContactMessage.MessageStatus.IN_PROGRESS);
    }

    @Override
    public ContactMessage markAsResolved(Long id) {
        return updateMessageStatus(id, ContactMessage.MessageStatus.RESOLVED);
    }

    @Override
    public long getMessageCountByStatus(ContactMessage.MessageStatus status) {
        return contactMessageRepository.countByStatus(status);
    }

    @Override
    public long getTotalMessageCount() {
        return contactMessageRepository.count();
    }

    @Override
    public long getNewMessageCount() {
        return getMessageCountByStatus(ContactMessage.MessageStatus.NEW);
    }

    @Override
    public long getInProgressMessageCount() {
        return getMessageCountByStatus(ContactMessage.MessageStatus.IN_PROGRESS);
    }

    @Override
    public long getResolvedMessageCount() {
        return getMessageCountByStatus(ContactMessage.MessageStatus.RESOLVED);
    }

    @Override
    public ContactMessage markAsRead(Long id) {
        return updateMessageStatus(id, ContactMessage.MessageStatus.READ);
    }

    @Override
    public ContactMessage markAsReplied(Long id) {
        return updateMessageStatus(id, ContactMessage.MessageStatus.REPLIED);
    }

    @Override
    public ContactMessage archiveMessage(Long id) {
        return updateMessageStatus(id, ContactMessage.MessageStatus.ARCHIVED);
    }

    @Override
    public List<ContactMessage> getRecentMessages(int days) {
        LocalDateTime cutoffDate = LocalDateTime.now().minusDays(days);
        return contactMessageRepository.findByCreatedAtAfter(cutoffDate);
    }

    @Override
    public List<ContactMessage> getUnreadMessages() {
        return getMessagesByStatus(ContactMessage.MessageStatus.NEW);
    }
}