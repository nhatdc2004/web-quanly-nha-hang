package com.manage.restaurant.model;

import jakarta.persistence.*; // Quan trọng: dùng jakarta.persistence cho Spring Boot 3+
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalTime;

@Getter
@Setter
@NoArgsConstructor // Constructor không tham số (cần cho JPA)
@AllArgsConstructor // Constructor với tất cả tham số (tiện lợi)
@Entity // Đánh dấu đây là một JPA Entity
@Table(name = "restaurants") // Chỉ định tên bảng trong database sẽ là "restaurants"
public class Restaurant {

    @Id // Đánh dấu đây là khóa chính
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Giá trị ID sẽ được tự động tăng bởi database
    private Long id;

    @Column(nullable = false, unique = true) // Không được null, giá trị phải là duy nhất
    private String name;

    @Column(nullable = false, length = 500) // Không được null, giới hạn độ dài
    private String address;

    private String phoneNumber; // Có thể null

    @Column(columnDefinition = "TEXT") // Cho phép lưu trữ đoạn văn bản dài
    private String description;

    private LocalTime openingTime;

    // Các mối quan hệ (ví dụ: với DiningTable, Booking) sẽ được thêm sau

    // Constructors, Getters, Setters đã được Lombok tự động tạo.
    // Bạn không cần viết chúng thủ công.
}
