package com.manage.restaurant.repository;

import com.manage.restaurant.model.Restaurant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RestaurantRepository extends JpaRepository<Restaurant, Long> {

    // Find restaurant by name
    Optional<Restaurant> findByName(String name);

    // Find restaurants by address containing
    List<Restaurant> findByAddressContainingIgnoreCase(String address);

    // Find restaurants by phone number
    Optional<Restaurant> findByPhoneNumber(String phoneNumber);

    // Check if restaurant exists by name
    boolean existsByName(String name);

    // Check if restaurant exists by phone number
    boolean existsByPhoneNumber(String phoneNumber);

    // Find restaurants by name containing (case insensitive)
    List<Restaurant> findByNameContainingIgnoreCase(String name);

    // Search restaurants by name or address
    @Query("SELECT r FROM Restaurant r WHERE LOWER(r.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(r.address) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Restaurant> findByNameOrAddressContainingIgnoreCase(@Param("keyword") String keyword);

    // Search restaurants by name or address (alternative method name)
    List<Restaurant> findByNameContainingIgnoreCaseOrAddressContainingIgnoreCase(String name, String address);
}