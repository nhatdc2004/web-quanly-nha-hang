package com.manage.restaurant.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "order_items")
public class OrderItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id", nullable = false)
    private Order order;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "menu_item_id", nullable = false)
    private MenuItem menuItem;

    @Column(nullable = false)
    private Integer quantity;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal price;

    @Column(columnDefinition = "TEXT")
    private String specialInstructions;

    // Constructor for easy creation
    public OrderItem(MenuItem menuItem, Integer quantity, BigDecimal price) {
        this.menuItem = menuItem;
        this.quantity = quantity;
        this.price = price;
    }

    public OrderItem(MenuItem menuItem, Integer quantity, BigDecimal price, String specialInstructions) {
        this.menuItem = menuItem;
        this.quantity = quantity;
        this.price = price;
        this.specialInstructions = specialInstructions;
    }

    // Helper method to calculate total price for this item
    public BigDecimal getTotalPrice() {
        return price.multiply(BigDecimal.valueOf(quantity));
    }
}