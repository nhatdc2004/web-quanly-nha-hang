package com.manage.restaurant.repository;

import com.manage.restaurant.model.MenuItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MenuItemRepository extends JpaRepository<MenuItem, Long> {

    // Find all available menu items
    List<MenuItem> findByAvailableTrue();

    // Find menu items by category
    List<MenuItem> findByCategoryAndAvailableTrue(String category);

    // Find all menu items by category (including unavailable)
    List<MenuItem> findByCategory(String category);

    // Search menu items by name (case insensitive)
    @Query("SELECT m FROM MenuItem m WHERE LOWER(m.name) LIKE LOWER(CONCAT('%', :name, '%')) AND m.available = true")
    List<MenuItem> findByNameContainingIgnoreCaseAndAvailableTrue(@Param("name") String name);

    // Get all distinct categories
    @Query("SELECT DISTINCT m.category FROM MenuItem m WHERE m.available = true")
    List<String> findDistinctCategories();

    // Find menu items within price range
    @Query("SELECT m FROM MenuItem m WHERE m.price BETWEEN :minPrice AND :maxPrice AND m.available = true")
    List<MenuItem> findByPriceBetweenAndAvailableTrue(@Param("minPrice") java.math.BigDecimal minPrice, 
                                                      @Param("maxPrice") java.math.BigDecimal maxPrice);
}